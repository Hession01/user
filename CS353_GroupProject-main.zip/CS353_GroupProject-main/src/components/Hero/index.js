import Hero from "./Hero.js";

export default Hero;