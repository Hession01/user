import Results from "./Results";

export default Results;